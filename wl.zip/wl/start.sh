#!/data/data/com.termux/files/usr/bin/bash

while true
do
  clear
  echo "BOT INICIANDO..."
  node /sdcard/download/wl/bot.js
  echo "♻️ bot.js foi encerrado. Reiniciando em 2 segundos..."
  sleep 2
done